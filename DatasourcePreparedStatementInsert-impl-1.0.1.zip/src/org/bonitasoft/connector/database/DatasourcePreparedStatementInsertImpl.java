/**
 * 
 */
package org.bonitasoft.connector.database;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.bonitasoft.engine.connector.ConnectorException;

import java.util.logging.Logger;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */

/**
 * BusinessLogic for Datasource PreparedStatement insert Bonita BPM connector. Run a query and return the primary key of the newly inserted row.
 * Database connection is obtain by a datasource
 * Connector has been tested only on Postgresql
 *  
 * @author fredk
 *
 */

public class DatasourcePreparedStatementInsertImpl extends
		AbstractDatasourcePreparedStatementInsertImpl {

	Connection connection;
	

	private static final Logger log = Logger.getLogger ("org.bonitasoft.debug");
	
	
	
	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getJndiName();
		//getPreparedStatment();
		//getSets();
	
		//TODO execute your business logic here 
		log.info (" DEBUG - START" );
		
		log.info (" DEBUG - before : connection: " + connection );
		try {
			connection = getJNDIConnection(getJndiName());
		} catch (NamingException e1) {
			log.severe("DEBUG : Exception message: " + e1.getMessage());
			log.severe("DEBUG : Exception explanation: " + e1.getExplanation());
			e1.printStackTrace();
		} catch (SQLException e1) {
			log.severe("DEBUG : Exception message: " + e1.getMessage());
			log.severe("DEBUG : Exception error code: " + e1.getErrorCode());
			e1.printStackTrace();
		}
		log.info (" DEBUG - after : connection: " + connection );
		
		
		try {
			log.info (" DEBUG - Before query" );
			String query = getPreparedStatement();
			log.info (" DEBUG - After query" );
			
			log.info (" DEBUG - Before statement" );
			PreparedStatement statement = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
			log.info (" DEBUG - After statement" );
			
			log.info (" DEBUG - START SET");	
			//SETS
			List l = getSets();
			for(int i = 0; i < l.size(); i++ ){
				ArrayList ligne = (ArrayList) l.get(i);
				log.info (" DEBUG - After ligne: " + ligne );
				
				if(!ligne.isEmpty()){
					String type = (String)ligne.get(0);
					String order = (String)ligne.get(1);
					String value = (String)ligne.get(2);
					
					log.info (" DEBUG - SET: i: " + i );
					//String
					if(type.equals("String")){
						log.info (" DEBUG - type is String");
						statement.setString(Integer.valueOf(order), value);
					
					//Integer	
					} else if(type.equals("Integer")){
						log.info (" DEBUG - type is Integer");
						statement.setInt(Integer.valueOf(order), Integer.valueOf(value));
					
					//Date	
					} else if(type.equals("Date")){
						log.info (" DEBUG - type is Date");
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						Date date;
						try {
							date = formatter.parse(value);
							java.sql.Date d = new java.sql.Date(date.getTime());
							statement.setDate(Integer.valueOf(order), d );
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							log.severe (" DEBUG - ParseException message" + e.getMessage()); 
							e.printStackTrace();
						}

					//Double	
					}else if(type.equals("Double")){
						log.info (" DEBUG - type is Double");
						Double valueD = Double.valueOf(value);
						statement.setBigDecimal(Integer.valueOf(order), BigDecimal.valueOf(valueD) );

					//UNDEFINED	
					} else{
						log.info (" DEBUG - type is UNDEFINED : review the entry parameter or the source code to manage the type: " + type);
					}
				}
			}		
			log.info (" DEBUG - END SET");	
					
			log.info (" DEBUG - START executeUpdate");		
			statement.executeUpdate();
			log.info (" DEBUG - END executeUpdate");
			
			log.info (" DEBUG - START getKey");
			ResultSet keys = statement.getGeneratedKeys();
			int genKey;
			if (keys.next()) {
				genKey = Integer.valueOf(keys.getInt(1));
				log.info("DEBUG : key is: " + genKey);
				
				//Set output
				setGeneratedKey(Integer.valueOf(genKey));				
			}else {
				log.info("Insert query doesn't return any result (no primary key returned)");
		    }	
			
			keys.close();
			keys= null;	
			
			statement.close();
			statement = null;				

			
		} catch (SQLException e) {
			log.severe("DEBUG : Exception message: " + e.getMessage());
			log.severe("DEBUG : Exception error code: " + e.getErrorCode());			
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				log.severe("DEBUG : Exception message: " + e.getMessage());
				log.severe("DEBUG : Exception error code: " + e.getErrorCode());
				e.printStackTrace();
			}
		}

	
		//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
		//setGeneratedKey(generatedKey);
	
	 }

	
	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server*
	
	}

	
	public static Connection getJNDIConnection(String jndiName)
			throws NamingException, SQLException {

		DataSource datasource = null;
		Connection connection = null;
		Context initialContext = new InitialContext();

		try {
			datasource = (DataSource) initialContext.lookup(jndiName);			
			connection = datasource.getConnection();
			//FIXME : Faire des retry ?
						
		} catch (NamingException e) {	
			initialContext = null;
			
			log.severe("NamingException: " + e.getMessage() + " "
					+ e.getExplanation());
			throw e;
		} catch (SQLException e) {
			initialContext = null;
			datasource = null;
			
			log.severe("SQLException: " + e.getMessage() + " "
					+ e.getErrorCode());
			throw e;
		}

		return connection;
	}	
	
	
	
	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
		try {
			connection.close();
		} catch (SQLException e) {
			log.severe("SQLException: " + e.getMessage() + " "
					+ e.getErrorCode());
			e.printStackTrace();
		}
		
	
	}

}
