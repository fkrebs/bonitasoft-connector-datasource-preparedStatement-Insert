package org.bonitasoft.connector.database;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractDatasourcePreparedStatementInsertImpl extends
		AbstractConnector {

	protected final static String JNDINAME_INPUT_PARAMETER = "jndiName";
	protected final static String PREPAREDSTATEMENT_INPUT_PARAMETER = "preparedStatement";
	protected final static String SETS_INPUT_PARAMETER = "sets";
	protected final String GENERATEDKEY_OUTPUT_PARAMETER = "generatedKey";

	protected final java.lang.String getJndiName() {
		return (java.lang.String) getInputParameter(JNDINAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPreparedStatement() {
		return (java.lang.String) getInputParameter(PREPAREDSTATEMENT_INPUT_PARAMETER);
	}

	protected final java.util.List getSets() {
		return (java.util.List) getInputParameter(SETS_INPUT_PARAMETER);
	}

	protected final void setGeneratedKey(java.lang.Integer generatedKey) {
		setOutputParameter(GENERATEDKEY_OUTPUT_PARAMETER, generatedKey);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getJndiName();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("jndiName type is invalid");
		}
		try {
			getPreparedStatement();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"preparedStatement type is invalid");
		}
		try {
			getSets();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("sets type is invalid");
		}

	}

}
